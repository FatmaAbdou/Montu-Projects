import React from 'react';
import { ThemeProvider } from './context/ThemeContext';
import PostWidget from './components/PostWidget';

export default function App() {
  return (
    <ThemeProvider>
      <main style={{ padding: '40px 20px', minHeight: '100vh', backgroundColor: '#f3f4f6' }}>
        <PostWidget />
      </main>
    </ThemeProvider>
  );
}
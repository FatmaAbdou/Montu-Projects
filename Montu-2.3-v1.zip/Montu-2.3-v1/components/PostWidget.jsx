import React, { useState } from 'react';
import { useFetch } from '../hooks/useFetch';
import { useTheme } from '../context/ThemeContext';

export default function PostWidget() {
  const [postId, setPostId] = useState(1);

  // Consume Context
  const { theme, toggleTheme } = useTheme();

  // Consume Custom Hook (Fetch + Cleanup + States)
  const { data: post, loading, error } = useFetch(
    `https://jsonplaceholder.typicode.com/posts/${postId}`
  );

  const isDark = theme === 'dark';

  return (
    <div
      style={{
        maxWidth: '440px',
        margin: '20px auto',
        padding: '24px',
        borderRadius: '10px',
        border: '1px solid',
        borderColor: isDark ? '#374151' : '#e5e7eb',
        backgroundColor: isDark ? '#1f2937' : '#ffffff',
        color: isDark ? '#f9fafb' : '#111827',
        fontFamily: 'system-ui, sans-serif',
        transition: 'all 0.2s ease',
      }}
    >
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '16px' }}>
        <h3 style={{ margin: 0 }}>Task 2.3 Widget</h3>
        <button
          onClick={toggleTheme}
          style={{
            padding: '6px 12px',
            borderRadius: '6px',
            border: '1px solid #d1d5db',
            cursor: 'pointer',
            backgroundColor: isDark ? '#374151' : '#f9fafb',
            color: isDark ? '#fff' : '#000',
          }}
        >
          {isDark ? '☀️ Light Mode' : '🌙 Dark Mode'}
        </button>
      </div>

      {/* Dynamic Controls */}
      <div style={{ display: 'flex', alignItems: 'center', gap: '12px', marginBottom: '16px' }}>
        <button
          onClick={() => setPostId((prev) => Math.max(1, prev - 1))}
          disabled={postId <= 1 || loading}
          style={{ padding: '8px 16px', borderRadius: '6px', cursor: 'pointer' }}
        >
          Previous
        </button>
        <span style={{ fontWeight: 'bold' }}>Post ID: {postId}</span>
        <button
          onClick={() => setPostId((prev) => prev + 1)}
          disabled={loading}
          style={{ padding: '8px 16px', borderRadius: '6px', cursor: 'pointer' }}
        >
          Next
        </button>
      </div>

      <hr style={{ margin: '16px 0', borderColor: isDark ? '#374151' : '#f3f4f6' }} />

      {/* Conditional UI Rendering */}
      {loading && <p>Fetching post data...</p>}

      {error && !loading && (
        <p style={{ color: '#ef4444' }}>Error: {error}</p>
      )}

      {!loading && !error && post && (
        <div>
          <h4 style={{ margin: '0 0 8px 0', textTransform: 'capitalize' }}>
            {post.title}
          </h4>
          <p style={{ margin: 0, lineHeight: '1.5', color: isDark ? '#d1d5db' : '#4b5563' }}>
            {post.body}
          </p>
        </div>
      )}
    </div>
  );
}